/* # NAVIGATION # */
var Navigation = {
	 init : function() {
	    var navTrigger   = $("nav span.label"),
	      	nav     = $("nav ul"),
	    	activeLabel = nav.find("a.active").text();
	      
	    navTrigger.empty().text(activeLabel);
	    
	    navTrigger.on("click", function() {
	      $(this).toggleClass('open');
	      nav.toggleClass('open');
	      

	    });
	}
}

/* # STICKY HEADER # */
var header = {
	sticky : function() {
		var didScroll;
		var lastScrollTop = 0;
		var delta = 5;
		var navbarHeight = $('.header-scroll').height();   
		var mainHeight   = $('header.header-main').height();   

		$(window).scroll(function(event){
		    didScroll = true;
		});

		setInterval(function() {
		    if (didScroll) {
		        hasScrolled();
		        didScroll = false;
		    }
		}, 0);

		function hasScrolled() {
		    var st = $(this).scrollTop();

		    if(Math.abs(lastScrollTop - st) <= delta)
		        return;
		    
		    if (st < mainHeight || (st > lastScrollTop && st > navbarHeight)){
		        $('header.header-scroll').removeClass('show');
	            $('header.header-scroll').addClass('hide');
		    } else if(st + $(window).height() < $(document).height()) {
	            $('header.header-scroll').addClass('show');
		        $('header.header-scroll').removeClass('hide');
		    }
		    
		    lastScrollTop = st;
		}
	}
}


/* # ARTICLE SLIDER # */
var articleSlider = {
	init: function() {
		var swiper = new Swiper('.swiper-article', {
			navigation: {
				nextEl: '.swiper-button-next',
				prevEl: '.swiper-button-prev',
			},
			pagination: {
        		el: '.swiper-pagination',
        		type: 'fraction'
      		},
	    });
	}
}

/* # ACCORDION / COLLAPSE # */
var accordion = {
	init : function() {
		$(".accordion").on('hidden.bs.collapse', function() {
			$(".accordion").find(".card-header").removeClass('open');
		});
		$(".accordion").on('shown.bs.collapse', function() {
			var card_active = $(this).find(".show");
			$(".accordion").find(".card-header").removeClass('open');
			card_active.prev(".card-header").addClass("open");
		});
		
	}
}
/* # STICKY SCROLLSPY NAV # */
var stickyNav = {
	init: function() {
		var elements = $('.sticky-nav');
		Stickyfill.add(elements);
	}
}